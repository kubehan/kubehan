---
title: 思科模拟器(Cisco Packet Tracer)汉化教程
author: Kubehan
type: post
date: 2020-03-04T03:01:33+08:00
url: /464.html
wb_dl_type:
  - 1
  - 1
views:
  - 2016
  - 2016
wb_dl_mode:
  - 0
  - 0
wb_down_local_url:
  - 
  - 
wb_down_url_ct:
  - 
  - 
wb_down_url:
  - 
  - 
wb_down_pwd:
  - 
  - 
post_views_count:
  - 0
  - 0
categories:
  - Linux运维

---
<!-- wp:paragraph -->

思科模拟器(Cisco Packet Tracer)汉化教程

<!-- /wp:paragraph -->

<!-- wp:paragraph -->

　　1、首先我们需要安装上面的步骤进行安装，安装完成后先不要打开软件，在下载的安装包里还有一个Chinese.ptl文件，这个文件是汉化的文件，我们需要将这个文件复制到思科模拟器(Cisco  
Packet  
Tracer)软件安装目录的Language文件夹下，我们可以在桌面找到软件的快捷方式，鼠标右键点击后选择属性然后找打它的起始位置，如下图所示。

<!-- /wp:paragraph -->

<!-- wp:image --><figure class="wp-block-image">

<img decoding="async" src="https://src.onlinedown.net/d/file/p/2017-11-02/f66dbab08626f6446b6f2d7ebc10a514.jpg" alt="思科模拟器(Cisco Packet Tracer)" /> </figure> 

<!-- /wp:image -->

<!-- wp:paragraph -->

　　3、将Chinese.ptl汉化文件复制到Language文件夹后，我们在打开运行思科模拟器(Cisco Packet  
Tracer)软件，进入主界面后打开Options选项，选择第一项Preferences，在Interface的选项卡下面有个“Select  
Language”在下面的框里选择“Chinese.ptl”然后点击右下角的”Change Language“。

<!-- /wp:paragraph -->

<!-- wp:image --><figure class="wp-block-image">

<img decoding="async" src="https://src.onlinedown.net/d/file/p/2018-11-29/caad8ee284434fd9bf240b0cb0e17c8a.png" alt="思科模拟器(Cisco Packet Tracer)" /> </figure> 

<!-- /wp:image -->

<!-- wp:image --><figure class="wp-block-image">

<img decoding="async" src="https://src.onlinedown.net/d/file/p/2017-11-02/91d35880dec1365db3c614c09b0983cd.jpg" alt="思科模拟器(Cisco Packet Tracer)" /> </figure> 

<!-- /wp:image -->

<!-- wp:paragraph -->

　　4、选择完成后保存退出，然后重启思科模拟器(Cisco Packet Tracer)软件进入到主界面就可以发现软件已经汉化了。(这是一个不完整汉化版，不过也够用了)

<!-- /wp:paragraph -->

<!-- wp:image --><figure class="wp-block-image">

<img decoding="async" src="https://src.onlinedown.net/d/file/p/2017-11-02/20fa83fc716a08b48c5c2cac17be00ca.jpg" alt="思科模拟器(Cisco Packet Tracer)" /> </figure> 

<!-- /wp:image -->

<!-- wp:paragraph -->

思科模拟器(Cisco Packet Tracer)常见问题

<!-- /wp:paragraph -->

<!-- wp:paragraph -->

　　**思科模拟器(Cisco Packet Tracer)怎么显示端口?**

<!-- /wp:paragraph -->

<!-- wp:paragraph -->

　　第一步：首先在本站下载安装好思科模拟器(Cisco Packet Tracer)软件后，我们打开进入软件主界面，点击界面中的options选项，然后在下拉的选项中再点击preferences进入该界面。

<!-- /wp:paragraph -->

<!-- wp:image --><figure class="wp-block-image">

<img decoding="async" src="https://src.onlinedown.net/d/file/p/2018-11-29/64323ab07f8643e576a42144178b9d6a.jpg" alt="思科模拟器(Cisco Packet Tracer)" /> </figure> 

<!-- /wp:image -->

<!-- wp:paragraph -->

　　第二步：进入到preferences界面后，我们在界面中的interface选项卡中勾选always show port labels选项，勾选完成后就可以关闭preferences设置界面了。

<!-- /wp:paragraph -->

<!-- wp:image --><figure class="wp-block-image">

<img decoding="async" src="https://src.onlinedown.net/d/file/p/2018-11-29/3cfd3c0a09d7ae0b10370b75a558a812.jpg" alt="思科模拟器(Cisco Packet Tracer)" /> </figure> 

<!-- /wp:image -->

<!-- wp:paragraph -->

　　第三步：退回到拓扑图界面中用户就可以看到链接端口标注了端口号了。

<!-- /wp:paragraph -->

<!-- wp:image --><figure class="wp-block-image">

<img decoding="async" src="https://src.onlinedown.net/d/file/p/2018-11-29/490e1c6c3f12910cada36e882588da60.jpg" alt="思科模拟器(Cisco Packet Tracer)" /> </figure> 

<!-- /wp:image -->