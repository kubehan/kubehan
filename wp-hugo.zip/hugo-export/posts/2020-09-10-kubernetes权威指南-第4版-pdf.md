---
title: Kubernetes权威指南 第4版.pdf
author: Kubehan
type: post
date: 2020-09-10T05:22:43+08:00
url: /2865.html
featured_image: https://www.kubehan.cn/wp-content/uploads/2020/09/1599715346-1651a6fdb1768a8.png
post_style:
  - sidebar
cao_price:
  - 29.9
cao_vip_rate:
  - 1
cao_status:
  - 1
cao_downurl:
  - https://pan.baidu.com/s/1uLZmxP14eMjbG_8XPuMbXw
cao_diy_btn:
  - 若成功购买未能下载获取资源，请右边点击客服联系在线客服处理！也可添加站长微信免费获取资源：pythondesign_cn
cao_pwd:
  - bq3x
cao_paynum:
  - 106
views:
  - 6770
categories:
  - Linux运维

---
<img decoding="async" src="https://www.kubehan.cn/wp-content/uploads/2020/09/1599715346-1651a6fdb1768a8.png" alt="file" />