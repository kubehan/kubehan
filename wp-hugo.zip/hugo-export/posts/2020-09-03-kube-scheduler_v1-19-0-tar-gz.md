---
title: kube-scheduler_v1.19.0.tar.gz
author: Kubehan
type: post
date: 2020-09-03T11:45:53+08:00
url: /2809.html
views:
  - 1740
post_style:
  - sidebar
cao_vip_rate:
  - 1
cao_status:
  - 1
cao_downurl:
  - https://www.kubehan.cn/wp-content/uploads/2020/09/1599133458-ff891ca616651ec.gz
cao_paynum:
  - 233
categories:
  - Linux运维

---
kube-scheduler_v1.19.0.tar.gz