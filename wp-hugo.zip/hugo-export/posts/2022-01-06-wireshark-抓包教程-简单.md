---
title: Wireshark 抓包教程---简单
author: Kubehan
type: post
date: 2022-01-06T03:33:18+08:00
url: /3051.html
featured_image: https://www.kubehan.cn/wp-content/uploads/2020/10/1603699862-62859bdf2ddb3e3.png
post_style:
  - sidebar
cao_vip_rate:
  - 1
views:
  - 1228
categories:
  - Linux运维

---
## Wireshark软件安装

软件下载路径：[wireshark官网][1]。按照系统版本选择下载，下载完成后，按照软件提示一路Next安装。

说明：如果你是Win10系统，安装完成后，选择抓包但是不显示网卡，下载win10pcap兼容性安装包。下载路径：[win10pcap兼容性安装包][2]  
软件安装很简单，不多说；  
主界面：  
<img decoding="async" src="https://www.kubehan.cn/wp-content/uploads/2020/10/1603699003-dd0ddd97a0f5698.png" alt="file" />  
抓包简单配置；  
打开软件选择网卡：如图所示操作<img decoding="async" src="https://www.kubehan.cn/wp-content/uploads/2020/10/1603699862-62859bdf2ddb3e3.png" alt="file" />

 [1]: https://www.wireshark.org/ "wireshark官网"
 [2]: http://www.win10pcap.org/download/ "win10pcap兼容性安装包"