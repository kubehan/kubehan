---
title: Wordpress强烈推荐的编辑器
author: Kubehan
type: post
date: 2020-04-26T08:50:29+08:00
url: /2316.html
Baidusubmit:
  - 1
views:
  - 954
zm_like:
  - 3
categories:
  - 关于博主

---
之前使用了各种编辑器都不尽人意，今天发现一款，非常喜欢，。推荐给大家

#### WP Githuber MD简介

WP Githuber MD是一款多功能的WordPress Markdown编辑器插件，它提供了多种功能，例如Markdown编辑器、实时预览、拼写检查、图像粘贴、HTML到Markdown帮助器等。  
WP Githuber MD 兼容经典编辑器和Gutenberg编辑器，可以为单个文章启用/禁用Markdown，支持自定义文章类型，支持代码语法高亮、流程图、甘特图、KaTex、数学公式渲染、 顺序图等等。

WP Githuber MD 是中国台湾开发者开发的，所以自带简体和繁体中文。

#### WP Githuber MD 的运行机制

WP Githuber MD会将您的Markdown内容保存到 wp\_posts.post\_content_filtered  
将Markdown解析为HTML，将解析后的HTML内容保存到 wp\_posts.post\_content  
该插件将检测您的Markdown内容并决定要加载哪些脚本，以避免加载不必要的脚本。例如，如果启用了代码语法高亮，则必须再次更新您的文章才能生效

#### 安装方式

后台搜索WP Githuber MD下载安装后启用就行

[点击前往编辑器][1]{.wp-editor-md-post-content-link}

 [1]: https://www.wpdaxue.com/wp-githuber-md-wordpress-markdown-editor.html "点击前往编辑器"