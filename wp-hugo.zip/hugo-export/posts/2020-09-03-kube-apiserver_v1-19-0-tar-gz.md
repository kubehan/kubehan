---
title: kube-apiserver_v1.19.0.tar.gz
author: Kubehan
type: post
date: 2020-09-03T11:44:44+08:00
url: /2807.html
views:
  - 944
post_style:
  - sidebar
cao_vip_rate:
  - 1
cao_status:
  - 1
cao_downurl:
  - https://www.kubehan.cn/wp-content/uploads/2020/09/1599126570-a8064011c3be5a5.zip
cao_paynum:
  - 85
categories:
  - Linux运维

---
